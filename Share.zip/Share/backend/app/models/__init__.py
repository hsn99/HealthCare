# app/models/__init__.py
from .patient import Patient
from .disease_history import DiseaseHistory
from .doctor import Doctor
